#ifndef __EXIT
#define __EXIT

#include<string>
#include "ParkingRate.h"
using namespace std;

namespace example
{
    class Exit
    {
        private:
            int cost;

        public:
            void process_payment(person);
            void payment_method();
            void print_ticket();
    };
}

#endif
