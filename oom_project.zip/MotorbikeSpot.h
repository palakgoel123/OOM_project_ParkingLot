#ifndef __MotorbikeSpot
#define __MotorbikeSpot



namespace example{
    class MotorbikeSpot
    {
    private:
        /* data */
    protected:
        static int MotorbikeSlot;
    public:
        bool isFull();

    };
}


#endif
