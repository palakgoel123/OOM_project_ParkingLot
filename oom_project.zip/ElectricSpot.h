#ifndef __ElectricSpot
#define __ElectricSpot



namespace example{
    class ElectricSpot
    {
        protected:
            static int ElectricSlot;
        public:
            bool isFull();
    };
}


#endif
