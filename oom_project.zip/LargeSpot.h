#ifndef __LargeSpot
#define __LargeSpot



namespace example{
    class LargeSpot
    {
    protected:
        static int LargeSlot;
    public:
        bool isFull();

    };

#endif
