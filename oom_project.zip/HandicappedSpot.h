#ifndef __HandicappedSpot
#define __HandicappedSpot

namespace example{
    class HandicappedSpot
    {
        protected:
            static int HandicapSlot;
        public:
            bool isFull();
    };
}
#endif
