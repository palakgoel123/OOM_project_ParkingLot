#include "Account.h"
#include <bits/stdc++.h>
using namespace std;
namespace example
{
    string ret_admin()
    {
        return password1;
    }
    string ret_attendant()
    {
        return password2;
    }

}
